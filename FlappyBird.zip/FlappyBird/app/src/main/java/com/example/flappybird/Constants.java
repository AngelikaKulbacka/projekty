package com.example.flappybird;

public class Constants {
    public static int SCREEN_WIDTH;
    public static int SCREEN_HEIGHT;
}
